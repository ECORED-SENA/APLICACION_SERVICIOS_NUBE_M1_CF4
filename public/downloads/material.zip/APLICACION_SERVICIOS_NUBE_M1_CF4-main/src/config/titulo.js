module.exports = 'Validación de requisitos'
